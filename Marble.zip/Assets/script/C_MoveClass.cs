﻿using UnityEngine;
using System.Collections;

public class C_MoveClass : MonoBehaviour {

    int MoveCount;
    RaycastHit hit;
	void Start () {
        StartCoroutine(Ch_Move());
	}
	IEnumerator Ch_Move()
    {
        while (true)
        {
            if (D_Manager.Instance.DiceValueChk)
            {
                MoveCount = D_Manager.Instance.getDiceValue();
                Debug.Log(MoveCount);
                for (int i = 1; i <= MoveCount; i++)
                {
                    if (transform.position.x < 8.0f && transform.position.x >= 0f && transform.position.z == 0f) //밑
                    {
                        transform.Translate(1, 0, 0);
                        yield return new WaitForSeconds(1.0f);
                    } else
                    if (transform.position.x == 8.0f && transform.position.z < 8.0f && transform.position.z >= 0f)//오른
                    {
                        transform.Translate(0, 0, 1);
                        yield return new WaitForSeconds(1.0f);
                    } else
                    if (transform.position.x <= 8.0f && transform.position.z == 8.0f && transform.position.x > 0f)//위
                    {
                        transform.Translate(-1, 0, 0);
                        yield return new WaitForSeconds(1.0f);
                    }else
                    if (transform.position.x == 0f && transform.position.z <= 8.0f && transform.position.z > 0f)//왼쪽
                    {
                        transform.Translate(0, 0, -1);
                        yield return new WaitForSeconds(1.0f);
                    }
                    if(i == MoveCount)
                    {
                        D_Manager.Instance.DiceValueChk = false;
                    }
                }
            }
            yield return new WaitForEndOfFrame();
        }
    }

}
