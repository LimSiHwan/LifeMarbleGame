﻿using UnityEngine;
using System.Collections;

public class DiceValueClass : MonoBehaviour {

    public int value = 1;
}
